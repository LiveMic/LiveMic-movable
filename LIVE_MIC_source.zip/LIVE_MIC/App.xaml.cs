using System.Windows;

namespace LIVE_MIC;

public partial class App : System.Windows.Application
{
    private LiveMicApplicationContext? _context;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _context = new LiveMicApplicationContext(this);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _context?.Dispose();
        base.OnExit(e);
    }
}
