using System;
using System.Drawing;
using System.Windows.Forms;
using Application = System.Windows.Application;

namespace LIVE_MIC;

public sealed class LiveMicApplicationContext : IDisposable
{
    private readonly Application _application;
    private readonly SettingsStore _settingsStore;
    private readonly NotifyIcon _notifyIcon;
    private readonly ToolStripMenuItem _activeMenuItem;
    private readonly ToolStripMenuItem _settingsMenuItem;
    private readonly ToolStripMenuItem _refreshMenuItem;
    private readonly ToolStripMenuItem _exitMenuItem;
    private readonly AppSettings _settings;
    private readonly OverlayWindow _overlayWindow;
    private readonly AudioMuteWatcher _muteWatcher;
    private SettingsWindow? _settingsWindow;
    private bool _isDisposed;

    public LiveMicApplicationContext(Application application)
    {
        _application = application;
        _settingsStore = new SettingsStore();
        _settings = _settingsStore.Load();

        _overlayWindow = new OverlayWindow(_settings);
        _overlayWindow.PositionChanged += OverlayWindow_PositionChanged;
        _overlayWindow.Show();
        _overlayWindow.ApplySettings();

        _muteWatcher = new AudioMuteWatcher();
        _muteWatcher.MuteChanged += MuteWatcher_MuteChanged;
        InitializeMuteWatcher();

        _activeMenuItem = new ToolStripMenuItem("Active") { Checked = _settings.IsActive, CheckOnClick = true };
        _activeMenuItem.CheckedChanged += ActiveMenuItem_CheckedChanged;

        _settingsMenuItem = new ToolStripMenuItem("Settings...");
        _settingsMenuItem.Click += SettingsMenuItem_Click;

        _refreshMenuItem = new ToolStripMenuItem("Refresh audio device");
        _refreshMenuItem.Click += RefreshMenuItem_Click;

        _exitMenuItem = new ToolStripMenuItem("Exit");
        _exitMenuItem.Click += ExitMenuItem_Click;

        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripLabel("LIVE_MIC"));
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(_activeMenuItem);
        menu.Items.Add(_settingsMenuItem);
        menu.Items.Add(_refreshMenuItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(_exitMenuItem);

        _notifyIcon = new NotifyIcon
        {
            Text = "LIVE_MIC",
            Visible = true,
            ContextMenuStrip = menu,
            Icon = SystemIcons.Information
        };
        _notifyIcon.DoubleClick += (_, _) => ShowSettingsWindow();

        ApplySettings();
    }

    private void InitializeMuteWatcher()
    {
        try
        {
            if (_muteWatcher.TryInitialize())
            {
                _overlayWindow.SetMuted(_muteWatcher.GetMute());
            }
            else
            {
                _overlayWindow.SetMuted(false);
            }
        }
        catch
        {
            _overlayWindow.SetMuted(false);
        }
    }

    private void MuteWatcher_MuteChanged(object? sender, bool isMuted)
    {
        _application.Dispatcher.Invoke(() => _overlayWindow.SetMuted(isMuted));
    }

    private void OverlayWindow_PositionChanged(object? sender, EventArgs e)
    {
        SaveSettings();
    }

    private void ActiveMenuItem_CheckedChanged(object? sender, EventArgs e)
    {
        _settings.IsActive = _activeMenuItem.Checked;
        ApplySettings();
        SaveSettings();
    }

    private void SettingsMenuItem_Click(object? sender, EventArgs e)
    {
        ShowSettingsWindow();
    }

    private void RefreshMenuItem_Click(object? sender, EventArgs e)
    {
        InitializeMuteWatcher();
    }

    private void ExitMenuItem_Click(object? sender, EventArgs e)
    {
        Dispose();
        _application.Shutdown();
    }

    private void ShowSettingsWindow()
    {
        if (_settingsWindow is null || !_settingsWindow.IsLoaded)
        {
            _settingsWindow = new SettingsWindow(_settings, () =>
            {
                ApplySettings();
                SaveSettings();
            }, SaveSettings);
            _settingsWindow.Show();
        }
        else
        {
            _settingsWindow.Activate();
            _settingsWindow.Topmost = true;
            _settingsWindow.Topmost = false;
        }
    }

    private void ApplySettings()
    {
        _activeMenuItem.Checked = _settings.IsActive;
        _overlayWindow.ApplySettings();
    }

    private void SaveSettings()
    {
        _settingsStore.Save(_settings);
    }

    public void Dispose()
    {
        if (_isDisposed)
        {
            return;
        }

        _isDisposed = true;
        SaveSettings();
        _notifyIcon.Visible = false;
        _notifyIcon.Dispose();
        _muteWatcher.Dispose();
        _overlayWindow.Close();
        _settingsWindow?.Close();
    }
}
