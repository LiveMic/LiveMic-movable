using System.Runtime.InteropServices;

namespace LIVE_MIC;

public sealed class MuteWatcher : IDisposable
{
    private IMMDeviceEnumerator? _deviceEnumerator;
    private IMMDevice? _device;
    private IAudioEndpointVolume? _endpointVolume;
    private AudioEndpointVolumeCallback? _callback;

    public event Action<bool>? MuteStateChanged;

    public bool CurrentMuteState { get; private set; }

    public void Start()
    {
        Refresh();
    }

    public void Refresh()
    {
        ReleaseCurrent();

        _deviceEnumerator = (IMMDeviceEnumerator)new MMDeviceEnumeratorComObject();
        Marshal.ThrowExceptionForHR(_deviceEnumerator.GetDefaultAudioEndpoint(EDataFlow.eCapture, ERole.eCommunications, out _device));

        Guid iid = typeof(IAudioEndpointVolume).GUID;
        Marshal.ThrowExceptionForHR(_device!.Activate(ref iid, 23, IntPtr.Zero, out object endpointObj));
        _endpointVolume = (IAudioEndpointVolume)endpointObj;

        Marshal.ThrowExceptionForHR(_endpointVolume.GetMute(out bool isMuted));
        CurrentMuteState = isMuted;

        _callback = new AudioEndpointVolumeCallback(OnMuteChanged);
        Marshal.ThrowExceptionForHR(_endpointVolume.RegisterControlChangeNotify(_callback));
    }

    private void OnMuteChanged(bool isMuted)
    {
        CurrentMuteState = isMuted;
        MuteStateChanged?.Invoke(isMuted);
    }

    private void ReleaseCurrent()
    {
        if (_endpointVolume is not null && _callback is not null)
        {
            try
            {
                _endpointVolume.UnregisterControlChangeNotify(_callback);
            }
            catch
            {
            }
        }

        _callback = null;

        if (_endpointVolume is not null)
        {
            Marshal.ReleaseComObject(_endpointVolume);
            _endpointVolume = null;
        }

        if (_device is not null)
        {
            Marshal.ReleaseComObject(_device);
            _device = null;
        }

        if (_deviceEnumerator is not null)
        {
            Marshal.ReleaseComObject(_deviceEnumerator);
            _deviceEnumerator = null;
        }
    }

    public void Dispose()
    {
        ReleaseCurrent();
    }
}

internal delegate void AudioEndpointVolumeCallbackDelegate(bool isMuted);

internal sealed class AudioEndpointVolumeCallback : IAudioEndpointVolumeCallback
{
    private readonly AudioEndpointVolumeCallbackDelegate _callback;

    public AudioEndpointVolumeCallback(AudioEndpointVolumeCallbackDelegate callback)
    {
        _callback = callback;
    }

    public int OnNotify(IntPtr notifyData)
    {
        AUDIO_VOLUME_NOTIFICATION_DATA data = Marshal.PtrToStructure<AUDIO_VOLUME_NOTIFICATION_DATA>(notifyData);
        _callback(data.bMuted);
        return 0;
    }
}

[StructLayout(LayoutKind.Sequential)]
internal struct AUDIO_VOLUME_NOTIFICATION_DATA
{
    public Guid guidEventContext;
    [MarshalAs(UnmanagedType.Bool)]
    public bool bMuted;
    public float fMasterVolume;
    public uint nChannels;
    public IntPtr afChannelVolumes;
}

internal enum EDataFlow
{
    eRender,
    eCapture,
    eAll,
    EDataFlow_enum_count
}

internal enum ERole
{
    eConsole,
    eMultimedia,
    eCommunications,
    ERole_enum_count
}

[ComImport]
[Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
internal class MMDeviceEnumeratorComObject
{
}

[ComImport]
[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface IMMDeviceEnumerator
{
    int EnumAudioEndpoints(EDataFlow dataFlow, int dwStateMask, out object devices);
    int GetDefaultAudioEndpoint(EDataFlow dataFlow, ERole role, out IMMDevice endpoint);
    int GetDevice(string pwstrId, out IMMDevice device);
    int RegisterEndpointNotificationCallback(IntPtr client);
    int UnregisterEndpointNotificationCallback(IntPtr client);
}

[ComImport]
[Guid("D666063F-1587-4E43-81F1-B948E807363F")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface IMMDevice
{
    int Activate(ref Guid iid, int dwClsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object interfacePointer);
    int OpenPropertyStore(int stgmAccess, out IntPtr properties);
    int GetId([MarshalAs(UnmanagedType.LPWStr)] out string id);
    int GetState(out int state);
}

[ComImport]
[Guid("5CDF2C82-841E-4546-9722-0CF74078229A")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface IAudioEndpointVolume
{
    int RegisterControlChangeNotify(IAudioEndpointVolumeCallback notify);
    int UnregisterControlChangeNotify(IAudioEndpointVolumeCallback notify);
    int GetChannelCount(out uint channelCount);
    int SetMasterVolumeLevel(float levelDb, Guid eventContext);
    int SetMasterVolumeLevelScalar(float level, Guid eventContext);
    int GetMasterVolumeLevel(out float levelDb);
    int GetMasterVolumeLevelScalar(out float level);
    int SetChannelVolumeLevel(uint channelNumber, float levelDb, Guid eventContext);
    int SetChannelVolumeLevelScalar(uint channelNumber, float level, Guid eventContext);
    int GetChannelVolumeLevel(uint channelNumber, out float levelDb);
    int GetChannelVolumeLevelScalar(uint channelNumber, out float level);
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool isMuted, Guid eventContext);
    int GetMute(out bool isMuted);
    int GetVolumeStepInfo(out uint step, out uint stepCount);
    int VolumeStepUp(Guid eventContext);
    int VolumeStepDown(Guid eventContext);
    int QueryHardwareSupport(out uint hardwareSupportMask);
    int GetVolumeRange(out float volumeMindB, out float volumeMaxdB, out float volumeIncrementdB);
}

[ComImport]
[Guid("657804FA-D6AD-4496-8A60-352752AF4F89")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
internal interface IAudioEndpointVolumeCallback
{
    int OnNotify(IntPtr notifyData);
}
