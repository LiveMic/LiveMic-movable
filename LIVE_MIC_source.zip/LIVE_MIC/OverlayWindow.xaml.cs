using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Shapes;
using MouseButtonEventArgs = System.Windows.Input.MouseButtonEventArgs;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using Point = System.Windows.Point;

namespace LIVE_MIC;

public partial class OverlayWindow : Window
{
    private readonly AppSettings _settings;
    private bool _isMuted;
    private bool _isDragging;
    private Point _dragMouseStart;
    private double _windowLeftStart;

    public event EventHandler? PositionChanged;

    private const int GWL_EXSTYLE = -20;
    private const int WS_EX_TRANSPARENT = 0x20;
    private const int WS_EX_TOOLWINDOW = 0x80;
    private const int WS_EX_NOACTIVATE = 0x08000000;

    [DllImport("user32.dll")]
    private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

    public OverlayWindow(AppSettings settings)
    {
        _settings = settings;
        InitializeComponent();
        UseLayoutRounding = true;
        SnapsToDevicePixels = true;
        Loaded += (_, _) =>
        {
            ApplySettings();
            ApplyClickThrough();
        };
        SourceInitialized += (_, _) => ApplyClickThrough();
        MouseLeftButtonDown += OverlayWindow_MouseLeftButtonDown;
        MouseLeftButtonUp += OverlayWindow_MouseLeftButtonUp;
        MouseMove += OverlayWindow_MouseMove;
    }

    private void OverlayWindow_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (!_settings.AllowDragPositioning || !_settings.IsActive)
        {
            return;
        }

        _isDragging = true;
        _dragMouseStart = PointToScreen(e.GetPosition(this));
        _windowLeftStart = Left;
        CaptureMouse();
    }

    private void OverlayWindow_MouseMove(object sender, MouseEventArgs e)
    {
        if (!_isDragging || !_settings.AllowDragPositioning || !_settings.IsActive)
        {
            return;
        }

        Point current = PointToScreen(e.GetPosition(this));
        double deltaX = current.X - _dragMouseStart.X;
        double screenWidth = SystemParameters.PrimaryScreenWidth;
        double maxLeft = Math.Max(0, screenWidth - Width);
        double newLeft = Math.Max(0, Math.Min(maxLeft, _windowLeftStart + deltaX));
        Left = newLeft;

        double denominator = Math.Max(1, screenWidth - Width);
        _settings.HorizontalPositionPercent = (int)Math.Round((newLeft / denominator) * 100.0);
    }

    private void OverlayWindow_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (!_isDragging)
        {
            return;
        }

        _isDragging = false;
        ReleaseMouseCapture();
        PositionChanged?.Invoke(this, EventArgs.Empty);
    }

    public void SetMuted(bool isMuted)
    {
        _isMuted = isMuted;
        CircleShape.Visibility = _isMuted ? Visibility.Collapsed : Visibility.Visible;
        SquareShape.Visibility = _isMuted ? Visibility.Visible : Visibility.Collapsed;
        UpdateShapeRegion();
    }

    public void ApplySettings()
    {
        double size = Math.Clamp(_settings.Size, 24, 256);
        Width = size;
        Height = size;

        double innerSize = Math.Max(8, size - 8);
        CircleShape.Width = innerSize;
        CircleShape.Height = innerSize;
        SquareShape.Width = innerSize;
        SquareShape.Height = innerSize;

        double opacity = Math.Clamp(1.0 - (_settings.TransparencyPercent / 100.0), 0.0, 1.0);
        RootGrid.Opacity = opacity;

        UpdatePosition();
        UpdateShapeRegion();
        ApplyClickThrough();

        if (_settings.IsActive)
        {
            if (!IsVisible)
            {
                Show();
            }
        }
        else
        {
            Hide();
        }
    }

    public void UpdatePosition()
    {
        double screenWidth = SystemParameters.PrimaryScreenWidth;
        double usableWidth = Math.Max(0, screenWidth - Width);
        double x = usableWidth * (Math.Clamp(_settings.HorizontalPositionPercent, 0, 100) / 100.0);
        Left = x;
        Top = 8;
    }

    private void UpdateShapeRegion()
    {
        Shape activeShape = _isMuted ? SquareShape : CircleShape;
        activeShape.UpdateLayout();

        Geometry? geometry = activeShape.RenderedGeometry?.Clone();
        if (geometry is null)
        {
            return;
        }

        GeneralTransform transform = activeShape.TransformToAncestor(RootGrid);
        Point topLeft = transform.Transform(new Point(0, 0));
        geometry.Transform = new TranslateTransform(topLeft.X, topLeft.Y);

        RootGrid.Clip = geometry;
    }

    private void ApplyClickThrough()
    {
        if (PresentationSource.FromVisual(this) is not HwndSource source)
        {
            return;
        }

        IntPtr hwnd = source.Handle;
        int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);
        exStyle |= WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;

        if (_settings.AllowDragPositioning && _settings.IsActive)
        {
            exStyle &= ~WS_EX_TRANSPARENT;
        }
        else
        {
            exStyle |= WS_EX_TRANSPARENT;
        }

        SetWindowLong(hwnd, GWL_EXSTYLE, exStyle);
    }
}
