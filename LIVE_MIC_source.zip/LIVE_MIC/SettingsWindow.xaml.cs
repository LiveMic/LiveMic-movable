using System.Windows;

namespace LIVE_MIC;

public partial class SettingsWindow : Window
{
    private readonly AppSettings _settings;
    private readonly Action _settingsChanged;
    private readonly Action _settingsSaved;
    private bool _isLoading;

    public SettingsWindow(AppSettings settings, Action settingsChanged, Action settingsSaved)
    {
        _settings = settings;
        _settingsChanged = settingsChanged;
        _settingsSaved = settingsSaved;

        InitializeComponent();
        LoadFromSettings();
        Closed += (_, _) => _settingsSaved();
    }

    private void LoadFromSettings()
    {
        _isLoading = true;
        SizeSlider.Value = _settings.Size;
        TransparencySlider.Value = _settings.TransparencyPercent;
        HorizontalPositionSlider.Value = _settings.HorizontalPositionPercent;
        AllowDragCheckBox.IsChecked = _settings.AllowDragPositioning;
        RefreshText();
        _isLoading = false;
    }

    private void RefreshText()
    {
        SizeValueText.Text = $"{(int)SizeSlider.Value}px";
        TransparencyValueText.Text = $"{(int)TransparencySlider.Value}%";
        HorizontalPositionValueText.Text = $"{(int)HorizontalPositionSlider.Value}%";
    }

    private void SizeSlider_OnValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        RefreshText();
        if (_isLoading) return;
        _settings.Size = (int)SizeSlider.Value;
        _settingsChanged();
    }

    private void TransparencySlider_OnValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        RefreshText();
        if (_isLoading) return;
        _settings.TransparencyPercent = (int)TransparencySlider.Value;
        _settingsChanged();
    }

    private void HorizontalPositionSlider_OnValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        RefreshText();
        if (_isLoading) return;
        _settings.HorizontalPositionPercent = (int)HorizontalPositionSlider.Value;
        _settingsChanged();
    }

    private void AllowDragCheckBox_OnChanged(object sender, RoutedEventArgs e)
    {
        if (_isLoading) return;
        _settings.AllowDragPositioning = AllowDragCheckBox.IsChecked == true;
        _settingsChanged();
    }

    private void ResetDefaults_OnClick(object sender, RoutedEventArgs e)
    {
        _settings.Size = AppSettings.Default.Size;
        _settings.TransparencyPercent = AppSettings.Default.TransparencyPercent;
        _settings.HorizontalPositionPercent = AppSettings.Default.HorizontalPositionPercent;
        _settings.AllowDragPositioning = AppSettings.Default.AllowDragPositioning;
        LoadFromSettings();
        _settingsChanged();
    }

    private void Close_OnClick(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
