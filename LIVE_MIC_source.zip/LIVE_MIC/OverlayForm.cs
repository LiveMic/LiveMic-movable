using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace LIVE_MIC;

internal sealed class OverlayForm : Form
{
    private bool _isMuted;
    private int _shapeSize;
    private int _transparencyPercent;

    public OverlayForm(int shapeSize, int transparencyPercent)
    {
        _shapeSize = shapeSize;
        _transparencyPercent = transparencyPercent;

        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        TopMost = true;
        DoubleBuffered = true;
        Width = _shapeSize;
        Height = _shapeSize;
        BackColor = Color.Black;
        Opacity = 1.0;

        RepositionTopCenter();
        ApplyShapeRegion();
        ApplyVisuals();
    }

    protected override bool ShowWithoutActivation => true;

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x00000080; // WS_EX_TOOLWINDOW
            cp.ExStyle |= 0x00000020; // WS_EX_TRANSPARENT
            cp.ExStyle |= 0x08000000; // WS_EX_NOACTIVATE
            return cp;
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
        e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

        using SolidBrush brush = new(_isMuted ? Color.LimeGreen : Color.Red);
        Rectangle rect = new(0, 0, ClientSize.Width - 1, ClientSize.Height - 1);

        if (_isMuted)
        {
            e.Graphics.FillRectangle(brush, rect);
        }
        else
        {
            e.Graphics.FillEllipse(brush, rect);
        }
    }

    public void SetMuted(bool isMuted)
    {
        if (_isMuted == isMuted)
        {
            return;
        }

        _isMuted = isMuted;
        ApplyShapeRegion();
        ApplyVisuals();
        Invalidate();
    }

    public void ApplySettings(int shapeSize, int transparencyPercent)
    {
        _shapeSize = Math.Clamp(shapeSize, 20, 400);
        _transparencyPercent = Math.Clamp(transparencyPercent, 0, 100);

        Width = _shapeSize;
        Height = _shapeSize;
        ApplyShapeRegion();
        RepositionTopCenter();
        ApplyVisuals();
        Invalidate();
    }

    private void ApplyShapeRegion()
    {
        GraphicsPath path = new();
        Rectangle rect = new(0, 0, Width, Height);

        if (_isMuted)
        {
            path.AddRectangle(rect);
        }
        else
        {
            path.AddEllipse(rect);
        }

        Region?.Dispose();
        Region = new Region(path);
        path.Dispose();
    }

    private void ApplyVisuals()
    {
        BackColor = _isMuted ? Color.LimeGreen : Color.Red;
        double visibleFraction = (100 - _transparencyPercent) / 100.0;
        visibleFraction = Math.Clamp(visibleFraction, 0.0, 1.0);
        Opacity = visibleFraction;
    }

    private void RepositionTopCenter()
    {
        Rectangle bounds = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1920, 1080);
        Left = bounds.Left + (bounds.Width - Width) / 2;
        Top = bounds.Top + 10;
    }
}
