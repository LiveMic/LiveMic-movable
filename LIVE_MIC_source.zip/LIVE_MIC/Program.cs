using System;
using System.Windows.Forms;

namespace LIVE_MIC;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new LiveMicApplicationContext());
    }
}
