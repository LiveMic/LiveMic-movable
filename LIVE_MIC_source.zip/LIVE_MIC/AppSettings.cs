using System.Text.Json;

namespace LIVE_MIC;

public sealed class AppSettings
{
    public bool IsActive { get; set; } = true;
    public int Size { get; set; } = 72;
    public int TransparencyPercent { get; set; } = 20;
    public int HorizontalPositionPercent { get; set; } = 50;
    public bool AllowDragPositioning { get; set; } = false;

    public static AppSettings Default => new();
}

public sealed class SettingsStore
{
    private readonly string _settingsPath;

    public SettingsStore()
    {
        string dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "LIVE_MIC");
        Directory.CreateDirectory(dir);
        _settingsPath = Path.Combine(dir, "settings.json");
    }

    public AppSettings Load()
    {
        try
        {
            if (!File.Exists(_settingsPath))
            {
                return AppSettings.Default;
            }

            string json = File.ReadAllText(_settingsPath);
            AppSettings? settings = JsonSerializer.Deserialize<AppSettings>(json);
            return settings ?? AppSettings.Default;
        }
        catch
        {
            return AppSettings.Default;
        }
    }

    public void Save(AppSettings settings)
    {
        var options = new JsonSerializerOptions { WriteIndented = true };
        string json = JsonSerializer.Serialize(settings, options);
        File.WriteAllText(_settingsPath, json);
    }
}
