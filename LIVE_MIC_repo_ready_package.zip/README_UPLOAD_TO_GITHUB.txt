Upload these to the root of your GitHub repo:
1. LIVE_MIC_source.zip
2. .github/workflows/build.yml  (use the included build.yml file content)

If your existing workflow already works, only replace LIVE_MIC_source.zip and run the workflow again.
